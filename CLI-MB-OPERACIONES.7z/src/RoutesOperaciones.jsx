import React from 'react'
import {BrowserRouter as Router,Route} from 'react-router-dom'
import Levantamiento from './componentesOperaciones/Levantamientos/Levantamiento';
import Control from './componentesOperaciones/Bitacoras/Control';
import BitacoraDR from './componentesOperaciones/Bitacoras/BitacoraDR';
import MainReportes from './componentesOperaciones/JustSemana/MainReportes';
import Pruebas from './componentesOperaciones/Lesionados/Pruebas';
import { MenuAccidentesScreen } from './componentesOperaciones/Lesionados/MenuAccidentesScreen';
import Colisiones from './componentesOperaciones/Colisiones/Colisiones';
import { AddRegisterEvent } from './componentesOperaciones/Lesionados/AddRegisterEvent';
import ListaAfectados from './componentesOperaciones/Lesionados/ListaAfectados';
import ListaDatosSeguro from "./componentesOperaciones/Lesionados/ListaDatosSeguro";
import ListaAmbulancia from "./componentesOperaciones/Lesionados/ListaAmbulancia";
import ListaTraslado from "./componentesOperaciones/Lesionados/ListaTrasladoHospital";
import { FormTraslado } from './componentesOperaciones/Lesionados/Formtraslado';
import Bienvenida from './componentesOperaciones/Main/Principal';
import { EventosScreen } from './componentesOperaciones/Lesionados/EventosScreen';
import { EventosForm } from './componentesOperaciones/Lesionados/EventosForm';

const Routes = () => {
    return ( 
        <Router>
            <div>
            <hr/>
                <Route path="/" component={Bienvenida} exact>
                </Route>
                <Route path="/JustificacionSemana" component={Levantamiento} exact>
                </Route>
                <Route path="/BitacordaDR" component={BitacoraDR} exact>
                </Route>
                <Route path="/ControlDeServicios" component={Control} exact>
                </Route>
                <Route path='/reportes/' component={MainReportes}/>
                <Route path='/pruebas' component={Pruebas}exact>
                </Route> 
                <Route path='/eventos/' component={EventosScreen}exact>
                </Route> 
                <Route path='/colisiones-form/' component={Colisiones}exactç>
                </Route>                
                <Route path='/MenuAccidentes/' component={MenuAccidentesScreen}exact>
                </Route>
                <Route exact path="/add-register/:idEvento" component={AddRegisterEvent} />                                               
                <Route exact path="/afectados/:idEvento" component={ListaAfectados} />                                               
                <Route exact path="/ambulancias/:idEvento" component={ListaAmbulancia} />                                               
                <Route exact path="/traslados/:idEvento" component={ListaTraslado} />                                                                                                            
                <Route exact path="/seguros/:idEvento" component={ListaDatosSeguro} />                                                                                                            
                <Route exact path="/lesiones-form" component={EventosForm} />                                                                                                            
                <Route exact path="/add-register-traslado/:idAfectado/:idEvento" component={FormTraslado} />                                                                                                            
            </div>
        </Router>
     );
}
 
export default Routes;