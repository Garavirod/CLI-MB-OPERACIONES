import React from 'react';
// import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';


  
  export default function Bienvenida() {
  return (
    <Container component="main">
		<h5>!Bienvenido Gabriel Gaspar! </h5>
		<br/>
  </Container>	
  
  );
}